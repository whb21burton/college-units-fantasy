import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
import { cookies } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';

// POST /api/join
// Body: { invite_code, team_name }
export async function POST(req: NextRequest) {
  const supabase = createRouteHandlerClient({ cookies });

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { invite_code, team_name } = await req.json();

  if (!invite_code || !team_name?.trim()) {
    return NextResponse.json({ error: 'invite_code and team_name are required.' }, { status: 400 });
  }

  // Find the league
  const { data: league } = await supabase
    .from('leagues')
    .select('id, league_size, status, buy_in')
    .eq('invite_code', invite_code.toUpperCase())
    .single();

  if (!league) {
    return NextResponse.json({ error: 'Invalid invite code. League not found.' }, { status: 404 });
  }

  if (league.status !== 'forming') {
    return NextResponse.json({ error: 'This league has already started. You can\'t join now.' }, { status: 409 });
  }

  // Check member count
  const { count } = await supabase
    .from('league_members')
    .select('*', { count: 'exact', head: true })
    .eq('league_id', league.id);

  if ((count || 0) >= league.league_size) {
    return NextResponse.json({ error: 'This league is full.' }, { status: 409 });
  }

  // Check not already a member
  const { data: existing } = await supabase
    .from('league_members')
    .select('id')
    .eq('league_id', league.id)
    .eq('user_id', user.id)
    .single();

  if (existing) {
    return NextResponse.json({ error: 'You\'re already in this league.' }, { status: 409 });
  }

  // Join
  const { error: joinError } = await supabase
    .from('league_members')
    .insert({
      league_id:  league.id,
      user_id:    user.id,
      team_name:  team_name.trim(),
      draft_slot: (count || 0) + 1,
      paid:       league.buy_in === 0,
    });

  if (joinError) {
    return NextResponse.json({ error: joinError.message }, { status: 500 });
  }

  // Log invite use
  await supabase.from('invite_uses').insert({
    league_id: league.id,
    used_by:   user.id,
  });

  return NextResponse.json({ data: { league_id: league.id }, error: null }, { status: 200 });
}
