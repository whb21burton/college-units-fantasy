'use client';

import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { supabase } from '@/lib/supabase-browser';
import type { League, LeagueMember } from '@/types';

const C = {
  bg:'#05080f', surf:'#0c1220', surf2:'#131d30', surf3:'#1e2d47',
  gold:'#d4a828', goldLight:'#f0c94a', muted:'#4a5d7a',
  text:'#e8edf5', sub:'#7a90b0', red:'#e74c3c', green:'#2ecc71',
};

export default function LeaguePage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const justJoined = searchParams.get('joined') === '1';

  const [league, setLeague]   = useState<League | null>(null);
  const [members, setMembers] = useState<LeagueMember[]>([]);
  const [userId, setUserId]   = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied]   = useState(false);
  const [starting, setStarting] = useState(false);

  const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { router.push('/'); return; }
      setUserId(user.id);

      const { data: leagueData } = await supabase
        .from('leagues')
        .select('*')
        .eq('id', params.id)
        .single();

      if (!leagueData) { router.push('/'); return; }
      setLeague(leagueData);

      const { data: membersData } = await supabase
        .from('league_members')
        .select('*, profile:profiles(display_name, avatar_url)')
        .eq('league_id', params.id)
        .order('draft_slot', { ascending: true });

      setMembers(membersData || []);
      setLoading(false);
    }
    load();

    // Realtime: update member list as people join
    const channel = supabase
      .channel(`league-${params.id}`)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public',
        table: 'league_members',
        filter: `league_id=eq.${params.id}`,
      }, () => load())
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [params.id]);

  const isCommissioner = userId === league?.commissioner_id;
  const isFull = members.length >= (league?.league_size || 999);
  const spotsLeft = (league?.league_size || 0) - members.length;
  const inviteUrl = league ? `${appUrl}/join/${league.invite_code}` : '';

  function copyLink() {
    navigator.clipboard.writeText(inviteUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  }

  async function startDraft() {
    if (!league || !isCommissioner) return;
    setStarting(true);
    // Shuffle member order into draft_order
    const shuffled = [...members].sort(() => Math.random() - .5).map(m => m.user_id);
    await supabase
      .from('leagues')
      .update({ status: 'drafting', draft_order: shuffled })
      .eq('id', league.id);
    router.push(`/league/${league.id}/draft`);
  }

  if (loading) return (
    <div style={{ minHeight: '100vh', background: C.bg, display: 'flex',
      alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ fontFamily: "'Oswald', sans-serif", color: C.muted,
        letterSpacing: 3, fontSize: 13 }}>Loading league...</div>
    </div>
  );

  return (
    <div style={{
      minHeight: '100vh', background: C.bg,
      backgroundImage: 'radial-gradient(ellipse 80% 30% at 50% -5%, rgba(212,168,40,.07) 0%, transparent 60%)',
    }}>
      <style>{`
        @keyframes fadeIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:none; } }
        .fade-in { animation: fadeIn .3s ease; }
      `}</style>

      {/* ── Nav ── */}
      <nav style={{
        position: 'sticky', top: 0, zIndex: 100,
        height: 56, display: 'flex', alignItems: 'center',
        padding: '0 24px', gap: 12,
        background: 'rgba(5,8,15,.95)',
        borderBottom: `2px solid ${C.gold}`,
        backdropFilter: 'blur(12px)',
      }}>
        <button onClick={() => router.push('/')} style={{
          background: 'none', border: 'none', cursor: 'pointer',
          fontFamily: "'Anton', sans-serif", fontSize: 16,
          letterSpacing: 2, color: C.gold, textTransform: 'uppercase',
        }}>🏈 CUF</button>
        <div style={{ width: 1, height: 20, background: C.surf3 }} />
        <span style={{ fontFamily: "'Oswald', sans-serif", fontSize: 13,
          color: C.sub, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis',
          whiteSpace: 'nowrap' }}>{league?.name}</span>
        <StatusBadge status={league?.status || 'forming'} />
      </nav>

      <div style={{ maxWidth: 760, margin: '0 auto', padding: '32px 20px' }}>

        {/* ── Joined toast ── */}
        {justJoined && (
          <div className="fade-in" style={{
            marginBottom: 20, padding: '14px 18px',
            background: 'rgba(46,204,113,.1)',
            border: '1px solid rgba(46,204,113,.3)',
            borderRadius: 10, display: 'flex', alignItems: 'center', gap: 12,
            fontFamily: "'Oswald', sans-serif", fontSize: 13, color: C.green,
          }}>
            🎉 You've joined <strong style={{ color: C.text }}>{league?.name}</strong>!
            Waiting for the draft to start.
          </div>
        )}

        {/* ── League header ── */}
        <div style={{ marginBottom: 28 }}>
          <h1 style={{ fontFamily: "'Anton', sans-serif", fontSize: 32,
            letterSpacing: 1.5, color: C.text, textTransform: 'uppercase',
            marginBottom: 4 }}>{league?.name}</h1>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            {[
              league?.buy_in === 0 ? '🆓 Free' : `💵 $${league?.buy_in} buy-in`,
              league?.draft_type === 'snake' ? '🐍 Snake draft' : '💰 Salary cap',
              `${league?.league_size} teams`,
            ].map(tag => (
              <span key={tag} style={{ fontFamily: "'Oswald', sans-serif",
                fontSize: 12, color: C.sub, letterSpacing: 1 }}>{tag}</span>
            ))}
          </div>
        </div>

        {/* ── Members list ── */}
        <div style={{
          background: C.surf, border: `1px solid ${C.surf3}`,
          borderRadius: 12, overflow: 'hidden', marginBottom: 20,
        }}>
          {/* Header */}
          <div style={{
            padding: '16px 20px',
            background: C.surf2,
            borderBottom: `1px solid ${C.surf3}`,
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          }}>
            <span style={{ fontFamily: "'Anton', sans-serif", fontSize: 15,
              letterSpacing: 1.5, color: C.text, textTransform: 'uppercase' }}>
              League Members
            </span>
            <span style={{
              fontFamily: "'Oswald', sans-serif", fontSize: 12, letterSpacing: 1,
              color: isFull ? C.gold : C.sub,
              background: isFull ? 'rgba(212,168,40,.1)' : 'transparent',
              padding: isFull ? '3px 10px' : '0',
              borderRadius: 4, border: isFull ? `1px solid rgba(212,168,40,.3)` : 'none',
            }}>
              {members.length} / {league?.league_size}
              {isFull ? ' — FULL' : ` — ${spotsLeft} spot${spotsLeft !== 1 ? 's' : ''} left`}
            </span>
          </div>

          {/* Member rows */}
          {members.map((m, i) => {
            const isMe = m.user_id === userId;
            const isComm = m.user_id === league?.commissioner_id;
            return (
              <div key={m.id} className="fade-in" style={{
                display: 'flex', alignItems: 'center', gap: 14,
                padding: '14px 20px',
                borderBottom: i < members.length - 1 ? `1px solid ${C.surf3}` : 'none',
                background: isMe ? 'rgba(212,168,40,.04)' : 'transparent',
              }}>
                {/* Draft slot */}
                <div style={{
                  width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
                  background: isMe ? C.gold : C.surf3,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: "'Anton', sans-serif", fontSize: 13,
                  color: isMe ? C.bg : C.muted,
                }}>{i + 1}</div>

                {/* Name */}
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontFamily: "'Oswald', sans-serif", fontWeight: 600,
                      fontSize: 15, color: isMe ? C.gold : C.text,
                      textTransform: 'uppercase', letterSpacing: .5 }}>
                      {m.team_name}
                    </span>
                    {isComm && (
                      <span style={{ fontFamily: "'Oswald', sans-serif", fontSize: 8,
                        letterSpacing: 2, color: C.gold,
                        background: 'rgba(212,168,40,.15)', padding: '2px 7px',
                        borderRadius: 3, border: '1px solid rgba(212,168,40,.3)' }}>
                        COMM
                      </span>
                    )}
                    {isMe && (
                      <span style={{ fontFamily: "'Oswald', sans-serif", fontSize: 8,
                        letterSpacing: 2, color: C.green,
                        background: 'rgba(46,204,113,.1)', padding: '2px 7px',
                        borderRadius: 3 }}>YOU</span>
                    )}
                  </div>
                  <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: 11,
                    color: C.muted, marginTop: 2 }}>
                    {(m.profile as any)?.display_name || 'Member'}
                    {league?.buy_in > 0 && (
                      <span style={{ marginLeft: 8, color: m.paid ? C.green : C.red }}>
                        {m.paid ? '✓ Paid' : '⏳ Unpaid'}
                      </span>
                    )}
                  </div>
                </div>

                {/* Draft slot label */}
                <div style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 10,
                  color: C.muted, letterSpacing: 1 }}>
                  Pick #{i + 1}
                </div>
              </div>
            );
          })}

          {/* Empty slots */}
          {Array.from({ length: spotsLeft }).map((_, i) => (
            <div key={`empty-${i}`} style={{
              display: 'flex', alignItems: 'center', gap: 14,
              padding: '14px 20px',
              borderBottom: i < spotsLeft - 1 ? `1px solid ${C.surf3}` : 'none',
              opacity: .4,
            }}>
              <div style={{
                width: 28, height: 28, borderRadius: '50%',
                border: `2px dashed ${C.surf3}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: "'Anton', sans-serif", fontSize: 12, color: C.muted,
              }}>{members.length + i + 1}</div>
              <span style={{ fontFamily: "'Oswald', sans-serif", fontSize: 13,
                color: C.muted, fontStyle: 'italic', letterSpacing: .5 }}>
                Waiting for invite...
              </span>
            </div>
          ))}
        </div>

        {/* ── Invite section (shown while forming) ── */}
        {league?.status === 'forming' && (
          <div style={{
            background: C.surf, border: `1px solid ${C.surf3}`,
            borderRadius: 12, padding: '20px', marginBottom: 20,
          }}>
            <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: 11,
              color: C.muted, letterSpacing: 2, textTransform: 'uppercase',
              marginBottom: 12 }}>📨 Invite Friends</div>

            <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
              <div style={{
                flex: 1, padding: '11px 14px',
                background: C.bg, border: `1px solid ${C.surf3}`,
                borderRadius: 8, fontFamily: "'IBM Plex Mono', monospace",
                fontSize: 12, color: C.gold,
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              }}>{inviteUrl}</div>
              <button onClick={copyLink} style={{
                flexShrink: 0, padding: '11px 18px',
                background: copied ? 'rgba(46,204,113,.2)' : C.gold,
                border: copied ? '1px solid rgba(46,204,113,.4)' : 'none',
                borderRadius: 8, cursor: 'pointer',
                fontFamily: "'Anton', sans-serif", fontSize: 12,
                letterSpacing: 2, color: copied ? C.green : C.bg,
                transition: 'all .2s',
              }}>
                {copied ? '✓' : 'Copy'}
              </button>
            </div>

            <div style={{ display: 'flex', gap: 8 }}>
              {[
                { label: '📱 Text', href: `sms:?body=Join my CFB fantasy league! ${inviteUrl}` },
                { label: '💬 WhatsApp', href: `https://wa.me/?text=${encodeURIComponent(`Join my CFB league: ${inviteUrl}`)}` },
                { label: '📧 Email', href: `mailto:?subject=Join my CFB Fantasy League&body=${encodeURIComponent(`Join here: ${inviteUrl}`)}` },
              ].map(({ label, href }) => (
                <a key={label} href={href} target="_blank" rel="noreferrer" style={{
                  flex: 1, textAlign: 'center', padding: '9px',
                  background: C.surf2, border: `1px solid ${C.surf3}`,
                  borderRadius: 8, textDecoration: 'none',
                  fontFamily: "'Oswald', sans-serif", fontSize: 11,
                  letterSpacing: 1, color: C.sub, transition: 'all .15s',
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = C.gold; e.currentTarget.style.color = C.text; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = C.surf3; e.currentTarget.style.color = C.sub; }}
                >{label}</a>
              ))}
            </div>
          </div>
        )}

        {/* ── Commissioner: start draft button ── */}
        {isCommissioner && league?.status === 'forming' && (
          <div style={{
            background: isFull
              ? 'linear-gradient(135deg,rgba(212,168,40,.12),rgba(212,168,40,.04))'
              : C.surf2,
            border: `1px solid ${isFull ? 'rgba(212,168,40,.4)' : C.surf3}`,
            borderRadius: 12, padding: '20px',
          }}>
            <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: 11,
              color: isFull ? C.gold : C.muted,
              letterSpacing: 2, textTransform: 'uppercase', marginBottom: 8 }}>
              Commissioner Controls
            </div>
            {!isFull && (
              <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: 12,
                color: C.sub, marginBottom: 16, letterSpacing: .5 }}>
                You can start the draft early, or wait until all {league.league_size} spots are filled.
              </div>
            )}
            {isFull && (
              <div style={{ fontFamily: "'Oswald', sans-serif", fontSize: 13,
                color: C.text, marginBottom: 16 }}>
                🎉 All spots filled! Ready to start the draft.
              </div>
            )}
            <button onClick={startDraft} disabled={starting} style={{
              width: '100%', padding: '15px',
              background: starting ? C.surf3 : `linear-gradient(135deg, ${C.gold}, ${C.goldLight})`,
              border: 'none', borderRadius: 8, cursor: starting ? 'wait' : 'pointer',
              fontFamily: "'Anton', sans-serif", fontSize: 15,
              letterSpacing: 2, textTransform: 'uppercase',
              color: starting ? C.muted : C.bg, transition: 'all .2s',
            }}>
              {starting ? '⏳ Starting...' : '🏈 Start Draft Now'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; color: string; bg: string }> = {
    forming:  { label: 'FORMING',   color: '#d4a828', bg: 'rgba(212,168,40,.1)' },
    drafting: { label: 'DRAFTING',  color: '#2ecc71', bg: 'rgba(46,204,113,.1)' },
    active:   { label: 'ACTIVE',    color: '#2ecc71', bg: 'rgba(46,204,113,.1)' },
    playoffs: { label: 'PLAYOFFS',  color: '#f0c94a', bg: 'rgba(240,201,74,.1)' },
    complete: { label: 'COMPLETE',  color: '#7a90b0', bg: 'rgba(122,144,176,.1)' },
  };
  const s = map[status] || map.forming;
  return (
    <span style={{
      fontFamily: "'Oswald', sans-serif", fontSize: 10,
      letterSpacing: 2, color: s.color, background: s.bg,
      border: `1px solid ${s.color}40`,
      padding: '3px 10px', borderRadius: 4,
    }}>{s.label}</span>
  );
}
